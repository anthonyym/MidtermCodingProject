package pkgShape;

public class SortByArea {

	public int compare(Cuboid c1, Cuboid c2) {

		double c1Area = c1.area();
		double c2Area = c2.area();
		
		if (c1Area - c2Area > 0) {
			return (int) Math.ceil(c1Area - c2Area);
		} else if (c1Area - c2Area < 0) {
			return (int) Math.floor(c1Area - c2Area);
		} else {
			return 0;
		}
		
	}


}
