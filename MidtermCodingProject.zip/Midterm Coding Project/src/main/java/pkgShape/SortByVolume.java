package pkgShape;

public class SortByVolume {

	public int compare(Cuboid c1, Cuboid c2) {

		double c1Volume = c1.volume();
		double c2Volume = c2.volume();
		
		if (c1Volume - c2Volume > 0) {
			return (int) Math.ceil(c1Volume - c2Volume);
		} else if (c1Volume - c2Volume < 0) {
			return (int) Math.floor(c1Volume - c2Volume);
		} else {
			return 0;
		}
		
	}
}
